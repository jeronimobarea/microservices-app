/**
 * ApiHealthCheckController
 *
 * @description :: Server-side logic for managing upstream alerts
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */


var _ = require('lodash');

module.exports = _.merge(_.cloneDeep(require('../base/Controller')), {


});

