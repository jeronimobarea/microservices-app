'use strict';

/**
 * Dummy JS file for smart IDEs like php/webStorm.
 *
 * Purpose of this file is to help IDE to use autocomplete features.
 */

// Debug / log helpers, see /config/application.js
var __filename;
var __line;
var __function;
var __stack;

// Sails is defined as global see /config/globals.js
var sails;
var exports;
